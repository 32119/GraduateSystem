package Dao;

public class zhuanli {
String	zhuanli_id;
String	student_id;
String	zhuanlimingcheng;
String	zhuanlileixing;
String	fabushijian;
String	zhuanlizhuangtai;
int	gongxiandupaiming;
String	zuozhengcailiao;
public String getZhuanli_id() {
	return zhuanli_id;
}
public void setZhuanli_id(String zhuanli_id) {
	this.zhuanli_id = zhuanli_id;
}
public String getStudent_id() {
	return student_id;
}
public void setStudent_id(String student_id) {
	this.student_id = student_id;
}
public String getZhuanlimingcheng() {
	return zhuanlimingcheng;
}
public void setZhuanlimingcheng(String zhuanlimingcheng) {
	this.zhuanlimingcheng = zhuanlimingcheng;
}
public String getZhuanlileixing() {
	return zhuanlileixing;
}
public void setZhuanlileixing(String zhuanlileixing) {
	this.zhuanlileixing = zhuanlileixing;
}
public String getFabushijian() {
	return fabushijian;
}
public void setFabushijian(String fabushijian) {
	this.fabushijian = fabushijian;
}
public String getZhuanlizhuangtai() {
	return zhuanlizhuangtai;
}
public void setZhuanlizhuangtai(String zhuanlizhuangtai) {
	this.zhuanlizhuangtai = zhuanlizhuangtai;
}
public int getGongxiandupaiming() {
	return gongxiandupaiming;
}
public void setGongxiandupaiming(int gongxiandupaiming) {
	this.gongxiandupaiming = gongxiandupaiming;
}
public String getZuozhengcailiao() {
	return zuozhengcailiao;
}
public void setZuozhengcailiao(String zuozhengcailiao) {
	this.zuozhengcailiao = zuozhengcailiao;
}

}
