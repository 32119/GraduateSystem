package Dao;

public class pingtai {
	String student_id;
String	pingtaimingcheng;
String	fuwudanwei;
String	shangxianshijian;
int	gongxiandupaiming;
String	zuozhengcailiao;
public String getStudent_id() {
	return student_id;
}
public void setStudent_id(String student_id) {
	this.student_id = student_id;
}
public String getPingtaimingcheng() {
	return pingtaimingcheng;
}
public void setPingtaimingcheng(String pingtaimingcheng) {
	this.pingtaimingcheng = pingtaimingcheng;
}
public String getFuwudanwei() {
	return fuwudanwei;
}
public void setFuwudanwei(String fuwudanwei) {
	this.fuwudanwei = fuwudanwei;
}
public String getShangxianshijian() {
	return shangxianshijian;
}
public void setShangxianshijian(String shangxianshijian) {
	this.shangxianshijian = shangxianshijian;
}
public int getGongxiandupaiming() {
	return gongxiandupaiming;
}
public void setGongxiandupaiming(int gongxiandupaiming) {
	this.gongxiandupaiming = gongxiandupaiming;
}
public String getZuozhengcailiao() {
	return zuozhengcailiao;
}
public void setZuozhengcailiao(String zuozhengcailiao) {
	this.zuozhengcailiao = zuozhengcailiao;
}

}
