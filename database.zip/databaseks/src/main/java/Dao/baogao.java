package Dao;

public class baogao {
String	student_id;
String	baogaomingcheng;;
String	baogaoleixing;
String	baogaoshijian;
String	baogaodanwei;
int	gongxiandupaiming;
String	zuozhengcailiao;
public String getStudent_id() {
	return student_id;
}
public void setStudent_id(String student_id) {
	this.student_id = student_id;
}
public String getBaogaomingcheng() {
	return baogaomingcheng;
}
public void setBaogaomingcheng(String baogaomingcheng) {
	this.baogaomingcheng = baogaomingcheng;
}
public String getBaogaoleixing() {
	return baogaoleixing;
}
public void setBaogaoleixing(String baogaoleixing) {
	this.baogaoleixing = baogaoleixing;
}
public String getBaogaoshijian() {
	return baogaoshijian;
}
public void setBaogaoshijian(String baogaoshijian) {
	this.baogaoshijian = baogaoshijian;
}
public String getBaogaodanwei() {
	return baogaodanwei;
}
public void setBaogaodanwei(String baogaodanwei) {
	this.baogaodanwei = baogaodanwei;
}
public int getGongxiandupaiming() {
	return gongxiandupaiming;
}
public void setGongxiandupaiming(int gongxiandupaiming) {
	this.gongxiandupaiming = gongxiandupaiming;
}
public String getZuozhengcailiao() {
	return zuozhengcailiao;
}
public void setZuozhengcailiao(String zuozhengcailiao) {
	this.zuozhengcailiao = zuozhengcailiao;
}

}
