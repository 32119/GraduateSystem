package Dao;

public class biaozhun {
    String	student_id;
    String	biaozhunmingcheng;
    String	biaozhunjibie;
    String	fabushijian;
    String	zuozhengcailiao;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getBiaozhunmingcheng() {
		return biaozhunmingcheng;
	}
	public void setBiaozhunmingcheng(String biaozhunmingcheng) {
		this.biaozhunmingcheng = biaozhunmingcheng;
	}
	public String getBiaozhunjibie() {
		return biaozhunjibie;
	}
	public void setBiaozhunjibie(String biaozhunjibie) {
		this.biaozhunjibie = biaozhunjibie;
	}
	public String getFabushijian() {
		return fabushijian;
	}
	public void setFabushijian(String fabushijian) {
		this.fabushijian = fabushijian;
	}
	public String getZuozhengcailiao() {
		return zuozhengcailiao;
	}
	public void setZuozhengcailiao(String zuozhengcailiao) {
		this.zuozhengcailiao = zuozhengcailiao;
	}

}
