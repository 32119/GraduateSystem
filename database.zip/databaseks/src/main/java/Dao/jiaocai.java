package Dao;

public class jiaocai {
    String  student_id;
    String  jiaocaimingcheng;
    String chubanshe;
    String chubanshijian;
    int  gongxiandupaiming;
    String zuozhengcailiao;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getJiaocaimingcheng() {
		return jiaocaimingcheng;
	}
	public void setJiaocaimingcheng(String jiaocaimingcheng) {
		this.jiaocaimingcheng = jiaocaimingcheng;
	}
	public String getChubanshe() {
		return chubanshe;
	}
	public void setChubanshe(String chubanshe) {
		this.chubanshe = chubanshe;
	}
	public String getChubanshijian() {
		return chubanshijian;
	}
	public void setChubanshijian(String chubanshijian) {
		this.chubanshijian = chubanshijian;
	}
	public int getGongxiandupaiming() {
		return gongxiandupaiming;
	}
	public void setGongxiandupaiming(int gongxiandupaiming) {
		this.gongxiandupaiming = gongxiandupaiming;
	}
	public String getZuozhengcailiao() {
		return zuozhengcailiao;
	}
	public void setZuozhengcailiao(String zuozhengcailiao) {
		this.zuozhengcailiao = zuozhengcailiao;
	}
}
