package Dao;

public class lunwen {
        String student_id;
        String  lunwenmingcheng;
        String kanwumingcheng;
        String lunwenzhuangtai;
        String fabiaoshijian;
      String  suoyinleixing;
      String guishukuqingkuang;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getLunwenmingcheng() {
		return lunwenmingcheng;
	}
	public void setLunwenmingcheng(String lunwenmingcheng) {
		this.lunwenmingcheng = lunwenmingcheng;
	}
	public String getKanwumingcheng() {
		return kanwumingcheng;
	}
	public void setKanwumingcheng(String kanwumingcheng) {
		this.kanwumingcheng = kanwumingcheng;
	}
	public String getLunwenzhuangtai() {
		return lunwenzhuangtai;
	}
	public void setLunwenzhuangtai(String lunwenzhuangtai) {
		this.lunwenzhuangtai = lunwenzhuangtai;
	}
	public String getFabiaoshijian() {
		return fabiaoshijian;
	}
	public void setFabiaoshijian(String fabiaoshijian) {
		this.fabiaoshijian = fabiaoshijian;
	}
	public String getSuoyinleixing() {
		return suoyinleixing;
	}
	public void setSuoyinleixing(String suoyinleixing) {
		this.suoyinleixing = suoyinleixing;
	}
	public String getGuishukuqingkuang() {
		return guishukuqingkuang;
	}
	public void setGuishukuqingkuang(String guishukuqingkuang) {
		this.guishukuqingkuang = guishukuqingkuang;
	}
}
